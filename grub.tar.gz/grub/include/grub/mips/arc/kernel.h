#include <grub/cpu/kernel.h>


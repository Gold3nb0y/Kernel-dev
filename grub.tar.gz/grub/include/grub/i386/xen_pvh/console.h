#include <grub/i386/pc/console.h>

#include <grub/i386/coreboot/boot.h>

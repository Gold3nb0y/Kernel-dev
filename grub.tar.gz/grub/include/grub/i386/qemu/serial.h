#include <grub/i386/coreboot/serial.h>

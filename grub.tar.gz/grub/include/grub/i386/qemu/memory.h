#include <grub/i386/coreboot/memory.h>

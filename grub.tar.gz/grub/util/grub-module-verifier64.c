#define MODULEVERIFIER_ELF64 1
#ifndef GRUB_MODULE_VERIFIERXX
#include "grub-module-verifierXX.c"
#endif

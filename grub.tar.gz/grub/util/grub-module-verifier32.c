#define MODULEVERIFIER_ELF32 1
#ifndef GRUB_MODULE_VERIFIERXX
#include "grub-module-verifierXX.c"
#endif

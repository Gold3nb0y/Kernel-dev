#define GRUB_SETUP_SPARC64 1
#include "setup.c"

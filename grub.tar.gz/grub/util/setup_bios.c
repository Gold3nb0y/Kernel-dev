#define GRUB_SETUP_BIOS 1
#include "setup.c"
